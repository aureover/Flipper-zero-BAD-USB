# OMG-Cable-Android-Script

## Upload Malicious APK to Android Device with an OMG Cable

**This script is for educational and pentesting purposes only!! Use at your own risk!**

### POC Video
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/aBZEvnvPAtk/0.jpg)](https://www.youtube.com/watch?v=aBZEvnvPAtk)
