 
# Change Network Configuration

A script used to change the network configuration on a Linux machine.

**Category**: Execution

## Description

A script used to change the network configuration on a Linux machine.

Opens a shel, get the network card name, set the network configuration, erase traces.

## Getting Started

### Dependencies

* Linux Permissions

### Executing program

* Plug in your device

### Settings

* Set the sudo password
* Change as you want the network configuration