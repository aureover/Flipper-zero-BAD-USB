# Close All Applications - BADUSB ✅

A script used to close all target open applications.

🟢 **Plug-And-Play** 🟢

**Category**: Execution

## Description

A script used to close all target open applications.

Opens PowerShell hidden, download a Python script, execute it, remove Python script downloaded, delete powershell history.

## Getting Started

### Dependencies

* Internet Connection
* Windows 10,11

### Executing program

* Plug in your device

### Settings

- No settings - Plug-And-Play
