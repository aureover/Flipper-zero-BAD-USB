**Title: FodCable - UAC Bypass**

Author: 0iphor13

Version: 1.0

What is FodCable?
#
*Use your O.MG Cable / Plug to bypass UAC using the old & well known Fodhelper.exe method, slightly modified.*
*It is likely that this will trigger Windows Defender - But still opening an elevated command prompt in 2022.*
#
