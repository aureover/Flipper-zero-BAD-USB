# Send Telegram Messages - Linux ✅

A script used to prank your friends sending messages by using Telegram app.

**Category**: Prank

## Description

A script used to prank your friends sending messages by using Telegram app.

Opens a shell, runs the telegram-desktop app, search the user by the id, enter into the chat, write the message(s) and send, then close the app and the shell.

## Getting Started

### Dependencies

* Internet Connection
* telegram-desktop installed and activated

### Executing program

* Plug in your device

### Settings

- Telegram username
- Messages
