 
# Change MAC Address

A script used to change the MAC address on a Linux machine.

**Category**: Execution

## Description

A script used to change the MAC address on a Linux machine.

Opens a shell, get the network card name, set the new MAC address, erase traces.

## Getting Started

### Dependencies

* Linux Permissions
* Internet Connection

### Executing program

* Plug in your device

### Settings

* Set the sudo password
* Change as you want the new MAC address