FalsePhilosopher's Squareware license <br>
Unless there are existing licenses included in this collection of works attached to any work of anything contained in this repository not having an existing license attached falls under the Squareware license.
The Squareware license is as follows <br>
You are free to use, modify, or redistribute anything falling under the SW license for private or public use as long as it retains the SW license attached to it.<br>
By using any works falling under the SW license you agree to not use anything for any kind monetary gains without first acquisitioning an agreement with Falsephilosopher to terms of such use and give up any rights of defense against any legal actions taken against myself or any entity I may represent for breaking the SW license agreement.<br>
If you like my work you can support the SW license by buying me a square meal.<br>
If you would like to contact me for any agreements relating to any SW licensed work you can contact me at falsephilosopher@proton.me
