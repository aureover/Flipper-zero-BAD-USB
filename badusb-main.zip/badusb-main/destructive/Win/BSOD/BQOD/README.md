# BQOD - tHE_bLUE_qUACK_oF_dEATH
A script for Rubber Ducky which uses the Invoke-bsod powershell technique to trigger a Blue Screen of Death

</BR>

</BR>
https://github.com/JonnyBanana/BQOD_tHE_bLUE_qUACK_oF_dEATH


https://github.com/peewpw/Invoke-BSOD


</BR>



![Alt text](https://raw.githubusercontent.com/JonnyBanana/BQOD_tHE_bLUE_qUACK_oF_dEATH/master/img/DUCKY-KILLERS.jpg)


</BR>

<h2>v1</h2>

</br>

<h3> Requirements</h3>

</br>

-Twin Duck Firmware

-Rubber Ducky Must be Named "_"

-BSOD.exe

</BR>

<h3>Os Compatibility</h3>
  
</BR>

-Windows Vista or Earlier

</BR>

![Alt text](https://raw.githubusercontent.com/JonnyBanana/BQOD_tHE_bLUE_qUACK_oF_dEATH/master/img/BSOD.JPG)

</BR>

<h2>v2</h2>

</br>

<h3>Requirements</h3>

</br>

-None

</BR>

<h3>Os Compatibility</h3>

</BR>

-Windows Vista or Earlier

</BR>

I also made a short video showing the bug, just click on the image below:

<a href="https://www.youtube.com/watch?v=hbukCE0nQqo
" target="_blank"><img src="https://raw.githubusercontent.com/JonnyBanana/BQOD_tHE_bLUE_qUACK_oF_dEATH/master/img/BQOD_BLUE_QUACK_OF_DEATH.jpg" 
alt="BQOD" width="700" height="450" border="100" /></a> 



</BR>


<h2>v3</h2>

</br>

<h3>Requirements</h3>

</br>

-None

</BR>

<h3>Os Compatibility</h3>

</BR>

-Windows Vista or Earlier

</BR>


</BR>

<!-- Banner -->
<div align="center">
<a href="https://www.purevpn.com/order-now.php?aff=44922&amp;a_bid=bbd0f893" target="_blank" ><img src="https://affiliates.purevpn.com/accounts/default1/6hb82wqa2l/bbd0f893.jpg" alt="Best VPN" title="Best VPN" width="728" height="90" /></a>
</BR></BR>
</div>





