
# privacy
This script will download and execute a large script that removes features that likely do not provide much privacy.

## How to use?

This script is plug and play.


## Features

- open powershell 
- download ps1 script
- provide privacy


## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


