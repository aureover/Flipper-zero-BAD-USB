
# WordPrank
Basically changes the Auto-Correction and makes "and" being corrected to "nad". But you can put any word you want.

## How to use?

This script is not plug and play. You need to the following changes:

- change first word "STRING and"
- change first word to anything you want "STRING nad" 


## Features

- open word
- change auto correction


## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


