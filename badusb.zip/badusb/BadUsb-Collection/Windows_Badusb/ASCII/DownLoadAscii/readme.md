
# DownloadAscii

These scripts will download an Ascii txt file and open it on the target pc.




## How to use?

These scripts are easy to use. Just plug the Flipper in and run the scripts. Please notice that an internet connection is required.




## Features

- Download .txt file
- open .txt file
- Fullscreen mode




## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


