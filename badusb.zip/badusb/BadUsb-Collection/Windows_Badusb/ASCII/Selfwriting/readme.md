
# WriteAscii

These scripts will open notepad and print out some Ascii images.




## How to use?

These scripts are easy to use. Just plug the Flipper in and run the scripts. No internet connection required.




## Features

- open new .txt file
- print the image
- Fullscreen mode




## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


