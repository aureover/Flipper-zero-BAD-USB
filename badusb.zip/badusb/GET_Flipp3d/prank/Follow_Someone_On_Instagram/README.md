# Follow someone on Instagram

This script can be used play a prank on friends by having them follow an Instagram account.

**Category**: Prank

## Description

This script can be used play a prank on friends by having them follow an Instagram account.

Open a PowerShell, start a process trough the default browser that go to an instagram link like this one `https://www.instagram.com/alessandro_greco_aka_aleff/` closing the PowerShell. Then use some TABs to go to Follow button and then close the browser.

## Note

Tested on:
- Windows 11 Eng
- Firefox Browser Eng

## Dependencies

* Internet Connection
* Instagram account logged in

## Settings

- You must set the Instagram account that you want to follow i.e. https://www.instagram.com/alessandro_greco_aka_aleff/

    `[17] DEFINE #INSTAGRAM_LINK example`

- It depends by the computer power and by the internet connection power

    `[32] DELAY 2000`