# Adding Gmail Forwarding Persistence

**This script is for educational and pentesting purposes only!! Use at your own risk!**
This Ducky Script will set up forwarding rules on a gmail account, and forward all incoming emails to the malicious actor. 
Note: The script requires that the user has logged into their google account in their Chrome browser. These sessions stay valid for a very long time, so the user just needs to have logged in once in the past few weeks.     

### POC Video
#### Adding Gmail Forwarding Persistence
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/yu2bvAcW4Rc/0.jpg)](https://www.youtube.com/watch?v=yu2bvAcW4Rc)
