**Title: FodCableII - UAC Bypass**

<p>Author: 0iphor13<br>
Version: 1.0<br>
Requirements: OMG Firmware v.2.5 or higher</p>

**What is FodCableII?**
#
*Use your O.MG Cable / Plug to bypass UAC using one of the Fodhelper.exe methods.*
*This POC will get you an elevated powershell instance and won't trigger AV at 04/2022*
#
!CleanUp will execute directly after execution!
