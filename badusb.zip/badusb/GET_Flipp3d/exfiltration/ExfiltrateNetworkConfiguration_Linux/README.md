 
# Exfiltrate Network Configuration - Linux ✅

A script used to exfiltrate the network configuration on a Linux machine.

**Category**: Exfiltrate, Execution

## Description

A script used to exfiltrate the network configuration on a Linux machine.

Opens a shell, get the network card name, get the network configuration using nmcli, send the result to Dropbox, erase traces.

## Getting Started

### Dependencies

* Internet Connection
* Dropbox Token

### Executing program

* Plug in your device

### Settings

* Set the Dropbox token