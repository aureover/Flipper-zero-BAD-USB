 
# Exfiltrate Linux Log Files - BADUSB ✅

A script used to take linux logs.

**Category**: Exfiltration, Execution

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Faleff-github%2Fmy-flipper-shits&count_bg=%233C3C3C&title_bg=%233C3C3C&icon=linux.svg&icon_color=%23FFFFFF&title=views&edge_flat=false)](https://github.com/aleff-github/my-flipper-shits)

## Description

A script used to take linux logs.

Opens a shel, zip all zippable (R permission) content of the log folder, send the zip into the dropbox folder, delete tmp folder.

## Getting Started

### Dependencies

* Internet Connection
* Linux System
* * Terminal that can be opened by the shortcommand CTRL-ALT t
* DropBox Account for the access token

### Executing program

* Plug in your device

### Settings

* Set your dropbox access token
* Change if needed the folder path interessed (i.e. /var/log)
* Change (if you think that it is necessary) the delay of the zipping operation
